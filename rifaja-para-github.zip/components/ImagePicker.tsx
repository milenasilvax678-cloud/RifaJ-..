"use client";
import { useEffect, useState } from "react";

// Escolhe imagem(ns) e mostra a prévia ANTES de salvar. O arquivo só vai para o servidor quando o formulário é enviado.
export default function ImagePicker({ name, multiple = false, label }: { name: string; multiple?: boolean; label?: string }) {
  const [urls, setUrls] = useState<string[]>([]);
  useEffect(() => () => urls.forEach((u) => URL.revokeObjectURL(u)), [urls]);
  return (
    <label className="grid gap-2 text-sm">
      {label}
      <input type="file" name={name} multiple={multiple} accept="image/jpeg,image/png,image/webp" className="w-full rounded-xl border border-slate-300 bg-white p-3"
        onChange={(e) => setUrls(Array.from(e.target.files ?? []).map((f) => URL.createObjectURL(f)))} />
      {!!urls.length && (
        <>
          <span className="text-xs font-bold text-amber-700">Prévia: ainda não salvo</span>
          <span className="grid grid-cols-3 gap-2">{urls.map((u) => /* eslint-disable-next-line @next/next/no-img-element */ <img key={u} src={u} alt="Prévia da foto" className="h-24 w-full rounded-lg object-cover" />)}</span>
        </>
      )}
    </label>
  );
}
