"use client";
import { motion } from "motion/react";
import type { Rede } from "../lib/social";
import SocialIcon, { ACAO, NOME_REDE, corDaMarca } from "./SocialIcon";

// variante "claro": cartão branco (funciona em fundo claro e escuro). variante "escuro": para o rodapé azul-escuro.
export default function SocialCards({ redes, variante = "claro" }: { redes: Rede[]; variante?: "claro" | "escuro" }) {
  const escuro = variante === "escuro";
  return (
    <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {redes.map((r, i) => {
        const { hex, escura } = corDaMarca(r.network);
        const cor = escura ? "64748B" : hex;
        return (
          <motion.li key={r.network} initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-30px" }}
            transition={{ duration: 0.4, delay: i * 0.05 }} whileHover={{ y: -4 }}
            className={`overflow-hidden rounded-2xl border shadow-sm transition-shadow hover:shadow-lg ${escuro ? "border-white/15 bg-white/5 text-white" : "border-slate-200 bg-white text-slate-900"}`}
            style={{ borderTop: `3px solid #${cor}` }}>
            <div className="flex h-full flex-col gap-3 p-4">
              <div className="flex items-center gap-3">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl" style={{ backgroundColor: escuro ? "#ffffff" : `#${cor}1f`, color: "#0A1B4D" }}>
                  <SocialIcon network={r.network} size={26} />
                </span>
                <h3 className="text-lg font-bold">{r.title || NOME_REDE[r.network]}</h3>
              </div>
              {r.description && <p className={`text-sm ${escuro ? "text-white/75" : "text-slate-600"}`}>{r.description}</p>}
              <a href={r.url} target="_blank" rel="noopener noreferrer"
                className={`mt-auto inline-flex items-center justify-center rounded-xl px-4 py-3 text-sm font-bold transition-colors ${escuro ? "bg-white text-[#0A1B4D] hover:bg-slate-200" : "bg-[#0A1B4D] text-white hover:bg-[#1E5BFF]"}`}>
                {ACAO[r.network] ?? "Visitar"}<span className="sr-only"> no {NOME_REDE[r.network]}</span>
              </a>
            </div>
          </motion.li>
        );
      })}
    </ul>
  );
}
