import { siInstagram, siTiktok, siWhatsapp, siYoutube, siFacebook, siTelegram, siDiscord } from "simple-icons";

// Logos vêm da biblioteca Simple Icons (uma por marca). Nada de ícone genérico.
const ICONES: Record<string, { title: string; hex: string; path: string }> = {
  instagram: siInstagram, tiktok: siTiktok, whatsapp: siWhatsapp, youtube: siYoutube, facebook: siFacebook, telegram: siTelegram, discord: siDiscord,
};
export const NOME_REDE: Record<string, string> = { instagram: "Instagram", tiktok: "TikTok", whatsapp: "WhatsApp", youtube: "YouTube", facebook: "Facebook", telegram: "Telegram", discord: "Discord" };
export const ACAO: Record<string, string> = { instagram: "Seguir", tiktok: "Seguir", whatsapp: "Conversar", youtube: "Assistir", facebook: "Curtir página", telegram: "Entrar no canal", discord: "Entrar na comunidade" };

export function corDaMarca(network: string) {
  const hex = ICONES[network]?.hex ?? "64748B";
  const [r, g, b] = [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
  const escura = 0.299 * r + 0.587 * g + 0.114 * b < 60; // marcas pretas (TikTok) usam a cor do texto
  return { hex, escura };
}
export default function SocialIcon({ network, size = 24, mono = false }: { network: string; size?: number; mono?: boolean }) {
  const i = ICONES[network];
  if (!i) return null;
  const { hex, escura } = corDaMarca(network);
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} role="img" aria-label={i.title} fill={mono || escura ? "currentColor" : `#${hex}`}>
      <path d={i.path} />
    </svg>
  );
}
