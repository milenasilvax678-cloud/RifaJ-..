export default function AreaChart({ dados }: { dados: { rotulo: string; valor: number }[] }) {
  const W = 640, H = 230, px = 36, py = 28;
  const max = Math.max(...dados.map((d) => d.valor), 1);
  const passo = (W - 2 * px) / Math.max(dados.length - 1, 1);
  const pts = dados.map((d, i) => [px + i * passo, H - py - (d.valor / max) * (H - 2 * py)] as const);
  const linha = pts.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`).join(" ");
  const area = `${linha} L${pts[pts.length - 1][0].toFixed(1)} ${H - py} L${px} ${H - py} Z`;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Receita recebida nos últimos 7 dias">
      <defs><linearGradient id="areaG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7C5CFF" stopOpacity="0.55" /><stop offset="1" stopColor="#7C5CFF" stopOpacity="0" /></linearGradient></defs>
      {[0, 0.5, 1].map((t) => <line key={t} x1={px} x2={W - px} y1={H - py - t * (H - 2 * py)} y2={H - py - t * (H - 2 * py)} stroke="#7F8FFF" strokeOpacity="0.18" />)}
      <path d={area} fill="url(#areaG)" />
      <path d={linha} fill="none" stroke="#9D8BFF" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" />
      {pts.map(([x, y], i) => <g key={i}><circle cx={x} cy={y} r="4.5" fill="#B9ADFF" stroke="#2D1B8C" strokeWidth="2" /><text x={x} y={H - 6} textAnchor="middle" fontSize="12" fill="#9FB0E8">{dados[i].rotulo}</text></g>)}
      <text x={px - 6} y={py + 4} textAnchor="end" fontSize="11" fill="#9FB0E8">R$ {Math.round(max)}</text>
    </svg>
  );
}
