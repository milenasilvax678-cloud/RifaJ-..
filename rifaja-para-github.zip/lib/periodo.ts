export type Filtro = { p?: string; de?: string; ate?: string };
const dia = (d: Date) => d.toLocaleDateString("sv"); // AAAA-MM-DD no fuso local
export function periodo(sp: Filtro) {
  const fim = new Date(); let ini = new Date();
  if (sp.p === "hoje") ini.setHours(0, 0, 0, 0);
  else if (sp.p === "custom" && sp.de) {
    ini = new Date(sp.de + "T00:00:00");
    if (sp.ate) fim.setTime(new Date(sp.ate + "T23:59:59").getTime());
  } else ini.setDate(ini.getDate() - (sp.p === "7" ? 7 : 30));
  return { ini: ini.toISOString(), fim: fim.toISOString(), iniDia: dia(ini), fimDia: dia(fim) };
}
export const brl = (c: number) => `R$ ${(c / 100).toFixed(2).replace(".", ",")}`;
