import { createClient } from "./supabase/server";
export type Rede = { network: string; url: string; title: string | null; description: string | null; position: number; show_footer: boolean; show_home: boolean; show_contact: boolean };

// O banco (RLS) só devolve redes ATIVAS e COM link. Rede sem link nunca aparece, então nunca há botão para página inexistente.
export async function redesPublicas(supabase: Awaited<ReturnType<typeof createClient>>): Promise<Rede[]> {
  const { data } = await supabase.from("social_links").select("network,url,title,description,position,show_footer,show_home,show_contact").order("position");
  return (data ?? []) as Rede[];
}
