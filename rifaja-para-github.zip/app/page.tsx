import Link from "next/link";
import { createClient } from "../lib/supabase/server";
import Reveal from "../components/Reveal";
import CampaignCard from "../components/CampaignCard";
import SocialCards from "../components/SocialCards";
import { redesPublicas } from "../lib/social";
export const dynamic = "force-dynamic";

const cols = "slug,name,description,category,status,cover_url,price_cents";
export default async function Home() {
  const supabase = await createClient();
  const redesHome = (await redesPublicas(supabase)).filter((r) => r.show_home);
  const [{ data: ativas }, { data: futuras }, { data: resultados }] = await Promise.all([

    supabase.from("campaigns").select(cols).eq("status", "ativa").order("created_at", { ascending: false }),
    supabase.from("campaigns").select(cols).eq("status", "agendada").order("starts_at"),
    supabase.from("campaign_results").select("id,winner_name,announcement,proof_url,drawn_at,campaigns(name)").eq("published", true).order("created_at", { ascending: false }).limit(9),
  ]);
  const vazio = (t: string) => <p className="rounded-2xl border-2 border-dashed border-slate-300 p-5 text-slate-600">{t}</p>;
  const grade = (l: any[] | null) => <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{l!.map((c) => <CampaignCard key={c.slug} c={c} />)}</div>;
  return (
    <main>
      <section className="bg-[#0A1B4D] px-4 py-14 text-white">
        <div className="mx-auto max-w-5xl">
          <Reveal>
            <h1 className="max-w-2xl text-4xl font-extrabold leading-tight md:text-6xl">Sua próxima oportunidade começa aqui.</h1>
            <p className="mt-4 max-w-xl text-lg text-[#C3D1FF]">Campanhas com regras claras e cada participação registrada na sua conta.</p>
            <div className="mt-6 flex gap-3">
              <Link href="/campanhas" className="rounded-xl bg-[#1E5BFF] px-5 py-3 font-bold shadow-[0_0_24px_#1E5BFF88]">Ver campanhas</Link>
              <Link href="/#como" className="rounded-xl border border-white/40 px-5 py-3 font-bold">Como funciona</Link>
            </div>
          </Reveal>
        </div>
      </section>
      <div className="mx-auto grid max-w-5xl gap-14 px-4 py-12">
        <Reveal><h2 className="mb-4 text-3xl font-extrabold">Rifas em destaque</h2>
          {ativas?.length ? grade(ativas) : vazio("Nenhuma rifa ativa no momento. As rifas aparecem aqui depois de aprovadas e validadas.")}</Reveal>
        <Reveal><h2 className="mb-4 text-3xl font-extrabold">Em breve</h2>
          {futuras?.length ? grade(futuras) : vazio("Nenhuma campanha agendada ainda.")}</Reveal>
        <Reveal><div id="promocoes" /><h2 className="mb-4 text-3xl font-extrabold">Promoções e cupons</h2>
          {vazio("Nenhuma promoção divulgada no momento. Cupons são validados no servidor na hora da participação.")}</Reveal>
        <Reveal><div id="como" /><h2 className="mb-4 text-3xl font-extrabold">Como funciona</h2>
          <ol className="grid gap-3">
            {["Crie sua conta com Google ou e-mail", "Escolha uma campanha e leia as regras", "Participe, usando um cupom se tiver", "Acompanhe o resultado na página da campanha"].map((t, i) => (
              <li key={t} className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-full bg-[#1E5BFF] font-extrabold text-white">{i + 1}</span>{t}</li>
            ))}
          </ol></Reveal>
        <Reveal><div id="resultados" /><h2 className="mb-4 text-3xl font-extrabold">Resultados oficiais</h2>
          {resultados?.length ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{resultados.map((r: any) => (
              <article key={r.id} className="rounded-2xl border bg-white p-4">
                <span className="text-xs font-bold text-[#1E5BFF]">Resultado oficial{r.drawn_at ? ` · ${new Date(r.drawn_at + "T12:00").toLocaleDateString("pt-BR")}` : ""}</span>
                <h3 className="text-lg font-bold">{r.campaigns?.name}</h3>
                <p><b>Ganhador:</b> {r.winner_name}</p>
                {r.announcement && <p className="text-sm text-slate-600">{r.announcement}</p>}
                {r.proof_url && <a href={r.proof_url} target="_blank" rel="noopener noreferrer" className="text-sm font-bold text-[#1E5BFF] underline">Ver comprovante</a>}
              </article>))}</div>
          ) : vazio("Ainda não há resultados publicados. Não exibimos ganhadores de exemplo.")}</Reveal>
        {redesHome.length > 0 && <Reveal><h2 className="mb-4 text-3xl font-extrabold">Siga o RifaJá</h2><SocialCards redes={redesHome} /></Reveal>}
        <Reveal><div id="ajuda" /><h2 className="mb-4 text-3xl font-extrabold">Perguntas frequentes</h2>
          {[["Preciso de conta para participar?", "Sim. A conta guarda seus pedidos e participações."],
            ["Como uso um cupom?", "Digite o código na hora de participar. O servidor confere validade, limites e elegibilidade."],
            ["Toda campanha aceita participação paga?", "Não. Cada rifa só fica ativa depois da validação jurídica feita pelo responsável."]].map(([q, a]) => (
            <details key={q} className="mb-2 rounded-xl border bg-white p-4"><summary className="cursor-pointer font-bold">{q}</summary><p className="mt-2 text-slate-600">{a}</p></details>
          ))}</Reveal>
      </div>
    </main>
  );
}
