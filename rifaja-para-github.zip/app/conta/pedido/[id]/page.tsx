import { notFound } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../../lib/supabase/server";
import { brl } from "../../../../lib/periodo";
import PaymentWatcher from "../../../../components/PaymentWatcher";
import CopyButton from "../../../../components/CopyButton";
import Aprovado from "../../../../components/Aprovado";
import QRCode from "qrcode";
import { brCode, formataChave } from "../../../../lib/pix";
import { cancelarPedido } from "./actions";
export const dynamic = "force-dynamic";

export default async function Pedido({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ erro?: string }> }) {
  const { id } = await params;
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: o } = await supabase.from("orders").select("id,status,total_cents,subtotal_cents,discount_cents,quantity,campaigns(name,slug)").eq("id", id).maybeSingle();
  if (!o) notFound();
  const [{ data: nums }, { data: pay }] = await Promise.all([
    supabase.from("campaign_numbers").select("number").eq("order_id", id).order("number"),
    supabase.from("payments").select("status,qr_code,qr_code_base64,expires_at,needs_review").eq("order_id", id).order("created_at", { ascending: false }).limit(1).maybeSingle(),
  ]);
  // PIX manual: sem cobrança de provedor, o dono do pedido recebe a chave (função do banco confere de quem é o pedido)
  const pixInfo = o.status === "pendente" && !pay?.qr_code ? (await supabase.rpc("order_pix", { p_order: id })).data as { key: string; name: string; city: string } | null : null;
  const { data: rv } = pixInfo ? await supabase.from("campaign_numbers").select("reserved_until").eq("order_id", id).limit(1).maybeSingle() : { data: null };
  const copiaCola = pixInfo ? brCode({ chave: pixInfo.key, nome: pixInfo.name, cidade: pixInfo.city, valorCentavos: o.total_cents, txid: "RJ" + id.replace(/-/g, "") }) : null;
  const qrManual = copiaCola ? await QRCode.toDataURL(copiaCola, { margin: 1, width: 280 }) : null;
  const numeros = (nums ?? []).map((n: any) => n.number as number);
  const camp = o.campaigns as any;
  return (
    <main className="mx-auto max-w-xl px-4 py-10">
      <Link href="/conta" className="text-sm font-bold text-[#1E5BFF]">← Minha conta</Link>
      <h1 className="mt-2 text-3xl font-extrabold">Pedido</h1>
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}

      {o.status === "confirmado" && <Aprovado numeros={numeros} />}

      <div className="mt-4 grid gap-2 rounded-2xl border bg-white p-4">
        <p><b>{camp?.name}</b></p>
        <p>Status: <b>{o.status}</b></p>
        {o.status !== "confirmado" && <p>Números: <b>{numeros.length ? numeros.join(", ") : "—"}</b></p>}
        <p>Subtotal {brl(o.subtotal_cents)} · Desconto {brl(o.discount_cents)}</p>
        <p className="text-xl font-extrabold">Total: {brl(o.total_cents)}</p>
      </div>

      {o.status === "pendente" && pay?.qr_code && (
        <div className="mt-4 grid gap-3 rounded-2xl border bg-white p-4 text-center">
          <h2 className="text-lg font-bold">Pague com PIX</h2>
          {pay.qr_code_base64 && /* eslint-disable-next-line @next/next/no-img-element */ <img src={`data:image/png;base64,${pay.qr_code_base64}`} alt="QR Code do PIX" className="mx-auto h-52 w-52" />}
          <p className="break-all rounded-lg bg-slate-100 p-2 text-xs">{pay.qr_code}</p>
          <CopyButton texto={pay.qr_code} />
          <PaymentWatcher orderId={o.id} expiraEm={pay.expires_at} />
          <form action={cancelarPedido}><input type="hidden" name="id" value={o.id} /><button className="text-sm font-bold text-red-700 underline">Cancelar e liberar os números</button></form>
        </div>
      )}
      {pixInfo && copiaCola && (
        <div className="mt-4 grid gap-3 rounded-2xl border bg-white p-4 text-center">
          <h2 className="text-lg font-bold">Pague com PIX</h2>
          {qrManual && /* eslint-disable-next-line @next/next/no-img-element */ <img src={qrManual} alt="QR Code do PIX" className="mx-auto h-56 w-56 rounded-xl" />}
          <p className="text-sm text-slate-600">Valor exato: <b className="text-lg">{brl(o.total_cents)}</b></p>
          <p className="break-all rounded-lg bg-slate-100 p-2 text-xs">{copiaCola}</p>
          <CopyButton texto={copiaCola} />
          <p className="text-sm">Chave PIX: <b>{formataChave(pixInfo.key)}</b></p>
          <p className="rounded-xl bg-amber-100 p-3 text-left text-sm text-amber-900">Depois de pagar, a equipe confere o pagamento e confirma os seus números. Para agilizar, envie o comprovante em <Link href="/suporte/novo" className="font-bold underline">Suporte</Link> (categoria Pagamento) citando o pedido <b>#{id.slice(0, 6)}</b>. Seus números ficam reservados até a conferência.</p>
          <PaymentWatcher orderId={o.id} expiraEm={rv?.reserved_until ?? null} />
          <form action={cancelarPedido}><input type="hidden" name="id" value={o.id} /><button className="text-sm font-bold text-red-700 underline">Cancelar e liberar os números</button></form>
        </div>
      )}
      {o.status === "pendente" && !pay?.qr_code && !pixInfo && <p className="mt-4 rounded-xl bg-amber-100 p-4 text-sm text-amber-900">Este pedido não tem cobrança ativa. Se precisar, cancele e tente de novo.</p>}
      {o.status === "cancelado" && <p className="mt-4 rounded-xl bg-slate-100 p-4 text-sm">Pedido cancelado ou expirado. Os números foram liberados. Se você pagou mesmo assim, fale com o <Link href="/suporte" className="font-bold underline">suporte</Link>.</p>}
      {pay?.needs_review && o.status !== "confirmado" && <p className="mt-4 rounded-xl bg-amber-100 p-4 text-sm text-amber-900">Recebemos um pagamento, mas ele precisa de conferência da equipe. Entraremos em contato.</p>}
    </main>
  );
}
