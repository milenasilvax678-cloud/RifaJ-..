import Link from "next/link";
import { createClient } from "../../lib/supabase/server";
import { redesPublicas } from "../../lib/social";
import { CATEGORIAS, quando } from "../../lib/suporte";
import StatusBadge from "../../components/StatusBadge";
import SocialCards from "../../components/SocialCards";
import Reveal from "../../components/Reveal";
export const dynamic = "force-dynamic";

const FAQ = [
  ["Como abro um chamado?", "Entre na sua conta, toque em Abrir chamado, escolha a categoria e descreva o problema. A equipe responde dentro do próprio chamado."],
  ["Paguei o PIX e meu número não apareceu como pago.", "O número só é marcado depois que o provedor confirma o pagamento. Aguarde alguns minutos e, se continuar, abra um chamado na categoria Pagamento."],
  ["Quanto tempo meus números ficam reservados?", "Só enquanto você paga. Se o pagamento não for confirmado a tempo, a reserva expira e os números voltam a ficar livres."],
  ["Como uso um cupom?", "Digite o código na hora de continuar para o pagamento. O servidor confere validade, limites e elegibilidade."],
  ["Posso cancelar uma participação?", "Pedidos pendentes podem ser cancelados em Minha conta. Pedidos já pagos dependem da análise da equipe: abra um chamado."],
  ["Onde vejo as respostas da equipe?", "Em Meus chamados. Você também recebe uma notificação em Minha conta quando houver resposta."],
];
const Icone = ({ d }: { d: string }) => (
  <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={d} /></svg>
);

export default async function Suporte() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const redes = (await redesPublicas(supabase)).filter((r) => r.show_contact);
  const { data: chamados } = user
    ? await supabase.from("support_tickets").select("id,ticket_number,subject,category,status,created_at,updated_at").eq("user_id", user.id).order("updated_at", { ascending: false }).limit(30)
    : { data: null };
  const cards = [
    { t: "Abrir chamado", d: "Conte o que aconteceu e acompanhe a resposta.", href: user ? "/suporte/novo" : "/login", icon: "M12 5v14M5 12h14", destaque: true },
    { t: "Meus chamados", d: "Veja o histórico e o status de cada atendimento.", href: user ? "#meus" : "/login", icon: "M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" },
    { t: "Perguntas frequentes", d: "Respostas rápidas para as dúvidas mais comuns.", href: "#faq", icon: "M9.1 9a3 3 0 0 1 5.8 1c0 2-3 2.5-3 4M12 17.5h.01M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z" },
  ];
  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <Reveal>
        <h1 className="text-4xl font-extrabold">Central de suporte</h1>
        <p className="mt-2 max-w-xl text-slate-600">Estamos aqui para ajudar com sua conta, pagamentos e participações.</p>
      </Reveal>
      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        {cards.map((c, i) => (
          <Reveal key={c.t} delay={i * 0.06}>
            <Link href={c.href} className={`flex h-full flex-col gap-2 rounded-2xl border p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-md ${c.destaque ? "border-[#1E5BFF] bg-[#1E5BFF] text-white" : "bg-white"}`}>
              <span className={`grid h-11 w-11 place-items-center rounded-xl ${c.destaque ? "bg-white/20" : "bg-[#1E5BFF]/10 text-[#1E5BFF]"}`}><Icone d={c.icon} /></span>
              <b className="text-lg">{c.t}</b><span className={`text-sm ${c.destaque ? "text-white/85" : "text-slate-600"}`}>{c.d}</span>
            </Link>
          </Reveal>))}
      </div>

      <section id="meus" className="mt-12">
        <h2 className="text-2xl font-extrabold">Meus chamados</h2>
        {!user ? <p className="mt-3 rounded-2xl border-2 border-dashed p-5 text-slate-600">Entre na sua conta para ver seus chamados. <Link href="/login" className="font-bold text-[#1E5BFF] underline">Entrar</Link></p>
          : chamados?.length ? (
            <ul className="mt-3 grid gap-3">
              {chamados.map((c: any) => (
                <li key={c.id}>
                  <Link href={`/suporte/${c.id}`} className="block rounded-2xl border bg-white p-4 shadow-sm transition hover:border-[#1E5BFF]">
                    <div className="flex flex-wrap items-center justify-between gap-2"><b>#{c.ticket_number} · {c.subject}</b><StatusBadge status={c.status} /></div>
                    <p className="mt-1 text-xs text-slate-500">{CATEGORIAS[c.category]} · aberto em {quando(c.created_at)} · última atualização {quando(c.updated_at)}</p>
                  </Link>
                </li>))}
            </ul>
          ) : <p className="mt-3 rounded-2xl border-2 border-dashed p-5 text-slate-600">Você ainda não abriu nenhum chamado.</p>}
      </section>

      <section id="faq" className="mt-12">
        <h2 className="text-2xl font-extrabold">Perguntas frequentes</h2>
        <div className="mt-3">{FAQ.map(([q, a]) => (
          <details key={q} className="mb-2 rounded-xl border bg-white p-4"><summary className="cursor-pointer font-bold">{q}</summary><p className="mt-2 text-slate-600">{a}</p></details>))}</div>
      </section>

      <section id="canais" className="mt-12">
        <h2 className="text-2xl font-extrabold">Nossos canais</h2>
        {redes.length ? <div className="mt-3"><SocialCards redes={redes} /></div>
          : <p className="mt-3 rounded-2xl border-2 border-dashed p-5 text-slate-600">Os canais oficiais aparecem aqui quando forem configurados pela equipe.</p>}
      </section>
    </main>
  );
}
