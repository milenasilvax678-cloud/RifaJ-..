import { notFound, redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../lib/supabase/server";
import { CATEGORIAS, quando } from "../../../lib/suporte";
import StatusBadge from "../../../components/StatusBadge";
import SubmitButton from "../../../components/SubmitButton";
import AutoRefresh from "../../../components/AutoRefresh";
import { responderChamado } from "../actions";
export const dynamic = "force-dynamic";

export default async function Chamado({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const { id } = await params;
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  // A regra de acesso é do banco: só o dono do chamado consegue ler (e notas internas da equipe nunca chegam aqui).
  const { data: t } = await supabase.from("support_tickets").select("id,ticket_number,subject,category,status,created_at,updated_at,user_id").eq("id", id).maybeSingle();
  if (!t || t.user_id !== user.id) notFound();
  const { data: msgs } = await supabase.from("ticket_messages").select("id,is_staff,body,created_at").eq("ticket_id", id).order("created_at");
  return (
    <main className="mx-auto max-w-2xl px-4 py-10">
      <AutoRefresh intervalMs={8000} />
      <Link href="/suporte#meus" className="text-sm font-bold text-[#1E5BFF]">← Meus chamados</Link>
      <h1 className="mt-2 text-2xl font-extrabold">#{t.ticket_number} · {t.subject}</h1>
      <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-500">
        <StatusBadge status={t.status} /><span>{CATEGORIAS[t.category]}</span><span>aberto em {quando(t.created_at)}</span><span>última atualização {quando(t.updated_at)}</span>
      </div>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}

      <ul className="mt-6 grid gap-3" aria-label="Conversa">
        {msgs?.map((m: any) => (
          <li key={m.id} className={`max-w-[88%] rounded-2xl p-3 ${m.is_staff ? "mr-auto rounded-bl-sm border bg-white" : "ml-auto rounded-br-sm bg-[#1E5BFF] text-white"}`}>
            <p className={`text-xs font-bold ${m.is_staff ? "text-[#1E5BFF]" : "text-white/80"}`}>{m.is_staff ? "Equipe RifaJá" : "Você"} · {quando(m.created_at)}</p>
            <p className="mt-1 whitespace-pre-line">{m.body}</p>
          </li>))}
      </ul>

      <form action={responderChamado} className="mt-6 grid gap-2 rounded-2xl border bg-white p-4">
        <input type="hidden" name="id" value={t.id} />
        <label className="grid gap-1 text-sm font-bold">{t.status === "resolvido" ? "Responder (reabre o chamado)" : "Sua resposta"}
          <textarea name="body" required maxLength={4000} rows={4} className="w-full rounded-xl border border-slate-300 p-3 font-normal" placeholder="Escreva sua mensagem…" /></label>
        <SubmitButton carregando="Enviando…">Enviar mensagem</SubmitButton>
      </form>
    </main>
  );
}
