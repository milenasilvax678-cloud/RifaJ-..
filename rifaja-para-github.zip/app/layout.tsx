import "./globals.css";
import Link from "next/link";
import Menu from "../components/Menu";
import Footer from "../components/Footer";
import Logo from "../components/Logo";
import { createClient } from "../lib/supabase/server";
import { redesPublicas } from "../lib/social";
export const metadata = { title: "RifaJá", description: "Sua próxima oportunidade começa aqui." };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const [{ data: { user } }, redes] = await Promise.all([supabase.auth.getUser(), redesPublicas(supabase)]);
  const ehAdmin = user ? !!(await supabase.rpc("is_admin")).data : false; // o link do painel só aparece para quem é administrador
  return (
    <html lang="pt-BR">
      <body className="min-h-screen">
        <header className="sticky top-0 z-30 bg-[#0A1B4D] text-white">
          <div className="mx-auto flex h-16 max-w-5xl items-center gap-2 px-4">
            <Menu redes={redes} admin={ehAdmin} />
            <Link href="/" aria-label="RifaJá, página inicial"><Logo /></Link>
            <span className="flex-1" />
            {user
              ? <Link href="/conta" className="rounded-lg border border-white/40 px-4 py-2 text-sm font-bold">Minha conta</Link>
              : <Link href="/login" className="rounded-lg bg-[#1E5BFF] px-4 py-2 text-sm font-bold">Entrar</Link>}
          </div>
        </header>
        {children}
        <Footer redes={redes.filter((r) => r.show_footer)} />
      </body>
    </html>
  );
}
