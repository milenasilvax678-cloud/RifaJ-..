export default function Loading() {
  return (
    <main className="mx-auto max-w-5xl animate-pulse px-4 py-10" aria-busy="true">
      <div className="h-10 w-2/3 rounded-xl bg-slate-200" />
      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        {[0, 1, 2].map((i) => <div key={i} className="h-40 rounded-2xl bg-slate-200" />)}
      </div>
    </main>
  );
}
