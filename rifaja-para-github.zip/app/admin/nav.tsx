// A navegação agora fica na barra lateral do layout do painel.
export default function AdminNav() { return null; }
