import { redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../lib/supabase/server";
import { brl } from "../../../lib/periodo";
import AdminNav from "../nav";
import { mudarStatusProduto } from "./actions";
export const dynamic = "force-dynamic";
const COR: Record<string, string> = { ativa: "bg-green-100 text-green-800", pausada: "bg-amber-100 text-amber-800", rascunho: "bg-slate-200 text-slate-700", pendente_revisao: "bg-blue-100 text-blue-800", agendada: "bg-blue-100 text-blue-800", encerrada: "bg-slate-300 text-slate-700", cancelada: "bg-red-100 text-red-800" };

export default async function Produtos({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const perm = async (p: string) => !!(await supabase.rpc("has_permission", { perm: p })).data;
  if (!(await perm("campaigns.read"))) redirect("/admin");
  const [escreve, aprova, envia] = await Promise.all([perm("campaigns.write"), perm("campaigns.approve"), perm("campaigns.submit")]);
  const [{ data: lista }, { data: cont }] = await Promise.all([
    supabase.from("campaigns").select("id,slug,name,status,price_cents,cover_url,total_numbers,legal_validated").order("created_at", { ascending: false }),
    supabase.rpc("campaign_counts"),
  ]);
  const k = (id: string) => (cont ?? []).find((x: any) => x.campaign_id === id) ?? { sold: 0, reserved: 0 };
  const Btn = ({ id, status, rot, cls }: { id: string; status: string; rot: string; cls: string }) => (
    <form action={mudarStatusProduto}><input type="hidden" name="id" value={id} /><input type="hidden" name="status" value={status} /><button className={`rounded-lg px-3 py-2 text-sm font-bold ${cls}`}>{rot}</button></form>
  );
  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <AdminNav />
      <h1 className="text-3xl font-extrabold">Produtos e prêmios</h1>
      <p className="text-slate-600">Edite foto, nome, preço e informações aqui. Não precisa mexer no código.</p>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {lista?.map((c: any) => (
          <article key={c.id} className="flex flex-col overflow-hidden rounded-2xl border bg-white shadow-sm">
            {c.cover_url /* eslint-disable-next-line @next/next/no-img-element */ ? <img src={c.cover_url} alt={c.name} className="h-40 w-full object-cover" />
              : <div className="grid h-40 place-items-center bg-[#13286B] text-4xl font-extrabold text-white">{c.name.charAt(0)}</div>}
            <div className="grid flex-1 gap-1 p-4">
              <span className={`w-fit rounded-full px-2 py-0.5 text-xs font-bold ${COR[c.status] ?? "bg-slate-200"}`}>{c.status}</span>
              <h2 className="text-lg font-bold">{c.name}</h2>
              <p className="text-sm text-slate-600">{c.price_cents != null ? `${brl(c.price_cents)} por número` : "Sem valor definido"}</p>
              <p className="text-xs text-slate-500">{k(c.id).sold} vendidos · {k(c.id).reserved} reservados · {c.total_numbers ?? "?"} no total</p>
              {!c.legal_validated && <p className="text-xs text-red-700">Validação jurídica pendente: não pode ser publicada.</p>}
            </div>
            <div className="flex flex-wrap gap-2 border-t p-3">
              {escreve && <Link href={`/admin/campanhas/${c.id}`} className="rounded-lg border px-3 py-2 text-sm font-bold">Editar</Link>}
              {(c.status === "rascunho" || c.status === "pausada") && aprova && <Btn id={c.id} status="ativa" rot={c.status === "pausada" ? "Retomar" : "Publicar"} cls="bg-green-700 text-white" />}
              {c.status === "rascunho" && !aprova && envia && <Btn id={c.id} status="pendente_revisao" rot="Enviar para revisão" cls="bg-[#1E5BFF] text-white" />}
              {c.status === "pendente_revisao" && aprova && <Btn id={c.id} status="ativa" rot="Aprovar e publicar" cls="bg-green-700 text-white" />}
              {(c.status === "ativa" || c.status === "agendada") && escreve && <Btn id={c.id} status="pausada" rot="Pausar" cls="bg-amber-600 text-white" />}
              <Link href={`/campanhas/${c.slug}`} className="rounded-lg border px-3 py-2 text-sm font-bold">{c.status === "ativa" ? "Ver no site" : "Pré-visualizar"}</Link>
            </div>
          </article>))}
        {!lista?.length && <p className="col-span-full rounded-2xl border-2 border-dashed p-5 text-slate-600">Nenhuma rifa criada. Crie a primeira em Rifas.</p>}
      </div>
    </main>
  );
}
