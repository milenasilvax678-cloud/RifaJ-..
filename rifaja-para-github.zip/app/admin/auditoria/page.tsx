import { redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../lib/supabase/server";
import AdminNav from "../nav";
export const dynamic = "force-dynamic";
const TABELAS = ["campaigns", "coupons", "admin_members", "roles", "role_permissions", "orders", "transactions", "expenses", "financial_adjustments", "site_settings", "support_tickets", "social_links", "payments"];

export default async function Auditoria({ searchParams }: { searchParams: Promise<{ t?: string }> }) {
  const { t } = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("has_permission", { perm: "audit.read" })).data) redirect("/admin");
  let q = supabase.from("audit_logs").select("id,actor_id,action,table_name,row_id,old_data,new_data,created_at").order("id", { ascending: false }).limit(100);
  if (t) q = q.eq("table_name", t);
  const { data: logs } = await q;
  const atores = [...new Set((logs ?? []).map((l) => l.actor_id).filter(Boolean))] as string[];
  const { data: perfis } = atores.length ? await supabase.from("profiles").select("id,email").in("id", atores) : { data: [] };
  const quem = (id: string | null) => (id ? perfis?.find((p) => p.id === id)?.email ?? id : "servidor");
  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <AdminNav />
      <h1 className="text-3xl font-extrabold">Auditoria</h1>
      <p className="text-slate-600">Últimas 100 ações. O histórico não pode ser editado nem apagado.</p>
      <div className="mt-4 flex flex-wrap gap-2">
        <Link href="/admin/auditoria" className="rounded-lg border bg-white px-3 py-1 text-sm font-bold">Todas</Link>
        {TABELAS.map((x) => <Link key={x} href={`/admin/auditoria?t=${x}`} className={`rounded-lg border px-3 py-1 text-sm ${t === x ? "bg-[#1E5BFF] text-white" : "bg-white"}`}>{x}</Link>)}
      </div>
      <ul className="mt-6 grid gap-2">
        {logs?.map((l) => (
          <li key={l.id} className="rounded-xl border bg-white p-3 text-sm">
            <b>{l.action}</b> em {l.table_name} · {quem(l.actor_id)} · {new Date(l.created_at).toLocaleString("pt-BR")}
            <details className="mt-1"><summary className="cursor-pointer text-[#1E5BFF]">Detalhes</summary>
              <pre className="mt-1 overflow-x-auto rounded bg-slate-100 p-2 text-xs">{JSON.stringify({ antes: l.old_data, depois: l.new_data }, null, 2)}</pre></details>
          </li>
        ))}
        {!logs?.length && <li className="rounded-xl border-2 border-dashed p-4 text-slate-600">Nenhum registro.</li>}
      </ul>
    </main>
  );
}
