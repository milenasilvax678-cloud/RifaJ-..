import Link from "next/link";
import { createClient } from "../../lib/supabase/server";
import { brl } from "../../lib/periodo";
import AreaChart from "../../components/AreaChart";
export const dynamic = "force-dynamic";

const ST: Record<string, [string, string]> = { confirmado: ["Pago", "bg-green-400/20 text-green-300"], pendente: ["Pendente", "bg-amber-400/20 text-amber-300"], cancelado: ["Cancelado", "bg-slate-400/20 text-slate-300"], reembolsado: ["Reembolsado", "bg-red-400/20 text-red-300"] };
const ACAO: Record<string, string> = { INSERT: "Criou", UPDATE: "Atualizou", DELETE: "Removeu", MANUAL_CONFIRM: "Confirmou manualmente", NUMERO_BLOQUEAR: "Reservou número em", NUMERO_LIBERAR: "Liberou número em", NUMERO_VENDER_MANUAL: "Venda manual em" };
const TAB: Record<string, string> = { campaigns: "rifa", coupons: "cupom", orders: "pedido", payments: "pagamento", support_tickets: "chamado", social_links: "rede social", expenses: "despesa", roles: "cargo", admin_members: "administrador", role_permissions: "permissão", transactions: "transação", financial_adjustments: "ajuste", site_settings: "configuração", campaign_results: "resultado", campaign_numbers: "números" };
const ha = (v: string) => { const m = Math.max(0, Math.floor((Date.now() - new Date(v).getTime()) / 60000)); return m < 60 ? `há ${m} min` : m < 1440 ? `há ${Math.floor(m / 60)} h` : `há ${Math.floor(m / 1440)} d`; };

export default async function Admin() {
  const supabase = await createClient();
  const perm = async (p: string) => !!(await supabase.rpc("has_permission", { perm: p })).data;
  const [fin, ords, aud, usr] = await Promise.all([perm("finance.read"), perm("orders.read"), perm("audit.read"), perm("users.read")]);
  const cnt = async (t: string, f?: (q: any) => any) => { let q = supabase.from(t).select("*", { count: "exact", head: true }); if (f) q = f(q); return (await q).count ?? 0; };
  const [ativas, premios, usuarios, pend, receitas, pedidos, ativ, cont] = await Promise.all([
    cnt("campaigns", (q) => q.eq("status", "ativa")), cnt("campaigns"), usr ? cnt("profiles") : Promise.resolve(null),
    ords ? supabase.from("payments").select("amount_cents").eq("status", "pendente") : Promise.resolve({ data: null }),
    fin ? supabase.from("transactions").select("amount_cents,occurred_at").eq("type", "receita").eq("status", "recebido").limit(5000) : Promise.resolve({ data: null }),
    ords ? supabase.from("orders").select("id,total_cents,status,created_at,campaigns(name,cover_url)").order("created_at", { ascending: false }).limit(5) : Promise.resolve({ data: null }),
    aud ? supabase.from("audit_logs").select("id,action,table_name,created_at").order("id", { ascending: false }).limit(6) : Promise.resolve({ data: null }),
    supabase.rpc("campaign_counts"),
  ]);
  const participacoes = (cont.data ?? []).reduce((a: number, c: any) => a + c.sold, 0);
  const rec = (receitas.data ?? []) as { amount_cents: number; occurred_at: string }[];
  const dias = Array.from({ length: 7 }, (_, i) => { const d = new Date(Date.now() - (6 - i) * 864e5); return { k: d.toLocaleDateString("sv", { timeZone: "America/Sao_Paulo" }), rotulo: d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", timeZone: "America/Sao_Paulo" }), valor: 0 }; });
  rec.forEach((r) => { const k = new Date(r.occurred_at).toLocaleDateString("sv", { timeZone: "America/Sao_Paulo" }); const d = dias.find((x) => x.k === k); if (d) d.valor += r.amount_cents / 100; });
  const temVendas = dias.some((d) => d.valor > 0);
  const pendentes = (pend.data ?? []) as { amount_cents: number }[];
  const kpis: [string, string | number, string, string][] = [
    ["Rifas ativas", ativas, "de " + premios + " cadastradas", "M3 8a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4z"],
    ["Prêmios cadastrados", premios, "rifas e rascunhos", "M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"],
    ["Participações", participacoes, "números pagos", "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8"],
    ["Pagamentos pendentes", ords ? pendentes.length : "—", ords ? brl(pendentes.reduce((a, p) => a + p.amount_cents, 0)) : "sem permissão", "M3 6h18v12H3zM3 10h18"],
    ["Receita total", fin ? brl(rec.reduce((a, r) => a + r.amount_cents, 0)) : "—", fin ? "pagamentos recebidos" : "sem permissão", "M12 2v20M17 6H9.5a3 3 0 0 0 0 6h5a3 3 0 0 1 0 6H6"],
    ["Usuários cadastrados", usuarios ?? "—", usr ? "contas no site" : "sem permissão", "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8M4 21a8 8 0 0 1 16 0"],
  ];
  const card = "rounded-3xl border border-[#7F8FFF33] bg-[#0F1A55]/60 p-5 backdrop-blur";
  return (
    <main>
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-6">
        {kpis.map(([t, v, s, d]) => (
          <div key={t} className={`${card} p-4`}>
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#4F46E5] to-[#2D6BFF] text-white"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={d} /></svg></span>
              <span className="text-xs text-[#9FB0E8]">{t}</span>
            </div>
            <div className="mt-2 text-2xl font-extrabold text-white">{v}</div>
            <div className="text-xs text-[#8FB0FF]">{s}</div>
          </div>))}
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.6fr_0.8fr_1.2fr]">
        <section className={card}>
          <h2 className="text-lg font-bold text-white">Vendas dos últimos 7 dias</h2>
          {fin ? (temVendas ? <AreaChart dados={dias} /> : <p className="mt-4 rounded-2xl border-2 border-dashed border-[#7F8FFF44] p-6 text-[#9FB0E8]">Sem vendas nos últimos 7 dias.</p>)
            : <p className="mt-4 text-[#9FB0E8]">Seu cargo não tem acesso ao financeiro.</p>}
        </section>
        <section className={card}>
          <h2 className="text-lg font-bold text-white">Ações rápidas</h2>
          <div className="mt-3 grid gap-2">
            {[["Nova rifa", "/admin/campanhas#nova", "from-[#7C5CFF] to-[#5B3FE0]"], ["Criar cupom", "/admin/cupons", "from-[#14B8A6] to-[#0E9F8E]"], ["Anunciar ganhador", "/admin/resultados", "from-[#22C55E] to-[#16A34A]"], ["Ver pagamentos", "/admin/pagamentos", "from-[#2D6BFF] to-[#1E50D6]"]].map(([t, h, g]) => (
              <Link key={t} href={h} className={`flex items-center gap-2 rounded-xl bg-gradient-to-r ${g} px-4 py-3 font-bold text-white transition hover:brightness-110`}><span aria-hidden="true">+</span>{t}</Link>))}
          </div>
        </section>
        <section className={card}>
          <div className="flex items-center justify-between"><h2 className="text-lg font-bold text-white">Últimos pedidos</h2><Link href="/admin/compras" className="text-xs font-bold text-[#8FB0FF]">Ver todos →</Link></div>
          <ul className="mt-3 grid gap-3">
            {(pedidos.data as any[] | null)?.map((o) => (
              <li key={o.id} className="flex items-center gap-3">
                {o.campaigns?.cover_url /* eslint-disable-next-line @next/next/no-img-element */ ? <img src={o.campaigns.cover_url} alt="" className="h-11 w-11 rounded-lg object-cover" /> : <span className="grid h-11 w-11 place-items-center rounded-lg bg-[#2D3FB0] font-bold text-white">{(o.campaigns?.name ?? "?").charAt(0)}</span>}
                <span className="min-w-0 flex-1 text-sm"><b className="block truncate text-white">#{o.id.slice(0, 4)} · {o.campaigns?.name}</b><span className="text-xs text-[#9FB0E8]">{ha(o.created_at)}</span></span>
                <span className="text-right text-sm"><b className="block text-white">{brl(o.total_cents)}</b><span className={`rounded-full px-2 py-0.5 text-xs font-bold ${ST[o.status]?.[1]}`}>{ST[o.status]?.[0] ?? o.status}</span></span>
              </li>))}
            {!pedidos.data?.length && <li className="text-sm text-[#9FB0E8]">{ords ? "Nenhum pedido ainda." : "Seu cargo não vê pedidos."}</li>}
          </ul>
        </section>
      </div>

      <section className={`${card} mt-4`}>
        <div className="flex items-center justify-between"><h2 className="text-lg font-bold text-white">Atividades recentes</h2>{aud && <Link href="/admin/auditoria" className="text-xs font-bold text-[#8FB0FF]">Ver todas →</Link>}</div>
        <ul className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {(ativ.data as any[] | null)?.map((a) => <li key={a.id} className="rounded-xl bg-white/5 p-3 text-sm"><b className="text-white">{ACAO[a.action] ?? a.action} {TAB[a.table_name] ?? a.table_name}</b><br /><span className="text-xs text-[#9FB0E8]">{ha(a.created_at)}</span></li>)}
          {!ativ.data?.length && <li className="text-sm text-[#9FB0E8]">{aud ? "Nenhuma atividade ainda." : "Seu cargo não vê a auditoria."}</li>}
        </ul>
      </section>
    </main>
  );
}
