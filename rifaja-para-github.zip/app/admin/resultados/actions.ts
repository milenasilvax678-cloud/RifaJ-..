"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../lib/supabase/server";

const txt = (fd: FormData, k: string) => (String(fd.get(k) ?? "").trim() || null);
const done = (ok: boolean, msg: string): never => redirect(`/admin/resultados?${ok ? "ok" : "erro"}=${encodeURIComponent(msg)}`);

export async function anunciarGanhador(fd: FormData) {
  const supabase = await createClient();
  const nome = txt(fd, "winner_name"), prova = txt(fd, "proof_url");
  if (!nome) done(false, "Informe o nome do ganhador.");
  if (prova && !/^https:\/\//i.test(prova)) done(false, "O link do comprovante precisa começar com https://");
  const { error } = await supabase.from("campaign_results").insert({
    campaign_id: txt(fd, "campaign_id"), winner_name: nome, announcement: txt(fd, "announcement"),
    proof_url: prova, drawn_at: txt(fd, "drawn_at"),
  });
  revalidatePath("/"); revalidatePath("/admin/resultados");
  done(!error, error ? error.message : "Resultado publicado no site.");
}

export async function alterarPublicacao(fd: FormData) {
  const supabase = await createClient();
  const { error } = await supabase.from("campaign_results").update({ published: fd.get("publicar") === "1" }).eq("id", txt(fd, "id"));
  revalidatePath("/"); revalidatePath("/admin/resultados");
  done(!error, error ? error.message : "Publicação atualizada.");
}
