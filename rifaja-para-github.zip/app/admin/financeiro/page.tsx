import { redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../lib/supabase/server";
import { periodo, brl, type Filtro } from "../../../lib/periodo";
import AdminNav from "../nav";
import BarChart from "../../../components/BarChart";
import { criarDespesa, criarAjuste } from "./actions";
export const dynamic = "force-dynamic";
const inp = "w-full rounded-xl border border-slate-300 bg-white p-3";

export default async function Financeiro({ searchParams }: { searchParams: Promise<Filtro & { ok?: string; erro?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const perm = async (p: string) => !!(await supabase.rpc("has_permission", { perm: p })).data;
  if (!(await perm("finance.read"))) redirect("/admin");
  const [podeEscrever, podeExportar] = await Promise.all([perm("finance.write"), perm("finance.export")]);

  const { ini, fim, iniDia, fimDia } = periodo(sp);
  const [tx, ex, aj] = await Promise.all([
    supabase.from("transactions").select("id,type,amount_cents,status,occurred_at,note").gte("occurred_at", ini).lte("occurred_at", fim).order("occurred_at", { ascending: false }),
    supabase.from("expenses").select("id,description,amount_cents,category,incurred_on,receipt_url").gte("incurred_on", iniDia).lte("incurred_on", fimDia).order("incurred_on", { ascending: false }),
    supabase.from("financial_adjustments").select("id,description,amount_cents,justification,created_at").gte("created_at", ini).lte("created_at", fim).order("created_at", { ascending: false }),
  ]);
  const t = tx.data ?? [], d = ex.data ?? [], a = aj.data ?? [];
  const urlComp = async (u: string | null) => !u ? null : u.startsWith("http") ? u : (await supabase.storage.from("receipts").createSignedUrl(u, 3600)).data?.signedUrl ?? null;
  const links = Object.fromEntries(await Promise.all(d.map(async (x) => [x.id, await urlComp(x.receipt_url)])));
  const porDia: Record<string, number> = {};
  t.filter((x) => x.type === "receita" && x.status === "recebido").forEach((x) => { const k = x.occurred_at.slice(0, 10); porDia[k] = (porDia[k] ?? 0) + x.amount_cents; });
  const serie = Object.entries(porDia).sort().map(([rotulo, valor]) => ({ rotulo: rotulo.slice(5), valor }));
  const soma = (tipo: string, st: string) => t.filter((x) => x.type === tipo && x.status === st).reduce((s, x) => s + x.amount_cents, 0);
  const bruta = soma("receita", "recebido"), pendente = soma("receita", "pendente");
  const taxas = soma("taxa", "recebido"), reemb = soma("reembolso", "recebido");
  const despesas = d.reduce((s, x) => s + x.amount_cents, 0), ajustes = a.reduce((s, x) => s + x.amount_cents, 0);
  const liquido = bruta - taxas - reemb - despesas + ajustes;

  const cards: [string, number, string?][] = [
    ["Receita recebida", bruta], ["Pendente de confirmação (não é receita)", pendente], ["Taxas dos provedores", taxas],
    ["Reembolsos", reemb], ["Despesas", despesas], ["Ajustes", ajustes], ["Resultado líquido (estimado)", liquido],
  ];
  const q = new URLSearchParams(Object.entries({ p: sp.p, de: sp.de, ate: sp.ate }).filter(([, v]) => v) as [string, string][]).toString();
  const filtro = (p: string, rot: string) => (
    <Link href={`/admin/financeiro?p=${p}`} className={`rounded-lg border px-3 py-2 text-sm font-bold ${((sp.p ?? "30") === p) ? "bg-[#1E5BFF] text-white" : "bg-white"}`}>{rot}</Link>
  );

  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <AdminNav />
      <h1 className="text-3xl font-extrabold">Financeiro</h1>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}

      <div className="mt-4 flex flex-wrap items-end gap-2">
        {filtro("hoje", "Hoje")}{filtro("7", "7 dias")}{filtro("30", "30 dias")}
        <form className="flex flex-wrap items-end gap-2">
          <input type="hidden" name="p" value="custom" />
          <input type="date" name="de" defaultValue={sp.de} aria-label="De" className="rounded-lg border p-2" />
          <input type="date" name="ate" defaultValue={sp.ate} aria-label="Até" className="rounded-lg border p-2" />
          <button className="rounded-lg border px-3 py-2 text-sm font-bold">Filtrar</button>
        </form>
        {podeExportar && <a href={`/admin/financeiro/export?${q}`} className="rounded-lg bg-[#0A1B4D] px-3 py-2 text-sm font-bold text-white">Exportar CSV</a>}
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map(([titulo, v]) => (
          <div key={titulo} className="rounded-2xl border bg-white p-4 shadow-sm">
            <div className="text-sm text-slate-500">{titulo}</div>
            <div className="text-2xl font-extrabold">{brl(v)}</div>
          </div>
        ))}
      </div>
      <BarChart dados={serie} />
      {!t.length && <p className="mt-4 rounded-xl border-2 border-dashed p-4 text-slate-600">Sem transações neste período.</p>}

      {podeEscrever && (
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <form action={criarDespesa} className="grid gap-3 rounded-2xl border bg-white p-4">
            <h2 className="text-xl font-bold">Registrar despesa</h2>
            <input name="description" required placeholder="Descrição" className={inp} />
            <input name="amount" required inputMode="decimal" placeholder="Valor em R$" className={inp} />
            <input name="category" placeholder="Categoria" className={inp} />
            <input type="date" name="incurred_on" className={inp} />
            <label className="text-sm">Comprovante (PDF ou imagem, até 5 MB)<input type="file" name="receipt_file" accept="application/pdf,image/*" className={inp} /></label>
            <input name="receipt_url" type="url" placeholder="ou link do comprovante" className={inp} />
            <button className="rounded-xl bg-[#1E5BFF] p-3 font-bold text-white">Salvar despesa</button>
          </form>
          <form action={criarAjuste} className="grid gap-3 rounded-2xl border bg-white p-4">
            <h2 className="text-xl font-bold">Ajuste financeiro</h2>
            <input name="description" required placeholder="Descrição" className={inp} />
            <div className="flex gap-2">
              <select name="sinal" className="rounded-xl border p-3"><option value="mais">+</option><option value="menos">−</option></select>
              <input name="amount" required inputMode="decimal" placeholder="Valor em R$" className={inp} />
            </div>
            <textarea name="justification" required minLength={10} placeholder="Justificativa (obrigatória)" className={inp} />
            <button className="rounded-xl bg-[#0A1B4D] p-3 font-bold text-white">Registrar ajuste</button>
            <p className="text-xs text-slate-500">Ajustes não podem ser editados nem apagados e ficam no histórico de auditoria.</p>
          </form>
        </div>
      )}

      <h2 className="mt-10 text-xl font-bold">Transações</h2>
      <ul className="mt-3 grid gap-2">
        {t.slice(0, 50).map((x) => (
          <li key={x.id} className="rounded-xl border bg-white p-3 text-sm">
            {new Date(x.occurred_at).toLocaleDateString("pt-BR")} · {x.type} · {brl(x.amount_cents)} · <b>{x.status}</b>
          </li>
        ))}
      </ul>
      <h2 className="mt-8 text-xl font-bold">Despesas</h2>
      <ul className="mt-3 grid gap-2">
        {d.map((x) => (
          <li key={x.id} className="rounded-xl border bg-white p-3 text-sm">
            {x.incurred_on} · {x.description} · {brl(x.amount_cents)}
            {links[x.id] && <> · <a className="text-[#1E5BFF] underline" href={links[x.id]!} target="_blank" rel="noopener noreferrer">comprovante</a></>}
          </li>
        ))}
        {!d.length && <li className="text-sm text-slate-600">Nenhuma despesa no período.</li>}
      </ul>
    </main>
  );
}
