import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../../../lib/supabase/server";
import { brl } from "../../../../../lib/periodo";
import AutoRefresh from "../../../../../components/AutoRefresh";
import NumberAdmin from "../../../../../components/NumberAdmin";
export const dynamic = "force-dynamic";

export default async function Numeros({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const { id } = await params;
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const perm = async (p: string) => !!(await supabase.rpc("has_permission", { perm: p })).data;
  if (!(await perm("orders.read"))) redirect("/admin");
  const [podeEditar, podeVender] = await Promise.all([perm("campaigns.write"), perm("payments.manual_confirm")]);
  const { data: c } = await supabase.from("campaigns").select("id,name,prize,total_numbers,price_cents,cover_url").eq("id", id).maybeSingle();
  if (!c) notFound();
  const { data: lista } = await supabase.rpc("admin_number_map", { p_campaign: id });
  const mapa: Record<number, { s: string; nome?: string | null; email?: string | null; pedido?: string | null }> = {};
  (lista ?? []).forEach((m: any) => { mapa[m.num] = { s: m.num_status, nome: m.buyer_name, email: m.buyer_email, pedido: m.num_order }; });
  const total = c.total_numbers ?? 0;
  const vend = (lista ?? []).filter((m: any) => m.num_status === "pago").length;
  const res = (lista ?? []).filter((m: any) => m.num_status === "reservado").length;
  const blo = (lista ?? []).filter((m: any) => m.num_status === "bloqueado").length;
  const card = "rounded-3xl border border-[#7F8FFF33] bg-[#0F1A55]/60 p-5 backdrop-blur";
  return (
    <main>
      <AutoRefresh campaignId={id} />
      <Link href="/admin/campanhas" className="text-sm font-bold text-[#8FB0FF]">← Rifas</Link>
      <h2 className="mt-1 text-2xl font-extrabold text-white">Editar números da rifa</h2>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}
      <div className="mt-4 grid gap-4 xl:grid-cols-[1fr_340px]">
        <section className={card}>
          {total
            ? <NumberAdmin campaignId={id} total={total} mapa={mapa} podeEditar={podeEditar} podeVender={podeVender} />
            : <p className="rounded-2xl border-2 border-dashed border-[#7F8FFF55] p-6 text-[#9FB0E8]">Defina a quantidade de números em <Link href={`/admin/campanhas/${id}`} className="font-bold text-[#8FB0FF] underline">Editar</Link> para a tabela aparecer.</p>}
        </section>
        <aside className="grid content-start gap-4">
          <section className={card}>
            {c.cover_url /* eslint-disable-next-line @next/next/no-img-element */ ? <img src={c.cover_url} alt={c.name} className="h-40 w-full rounded-2xl object-cover" /> : null}
            <h3 className="mt-3 text-lg font-bold text-white">{c.name}</h3>
            {c.prize && <p className="text-sm text-[#C3D1FF]">{c.prize}</p>}
            <p className="mt-2 text-sm text-[#9FB0E8]">{c.price_cents != null ? `${brl(c.price_cents)} por número` : "Sem valor definido"} · {total} números</p>
            <p className="mt-1 text-sm">Pagos <b className="text-green-400">{vend}</b> · Reservados <b className="text-amber-300">{res}</b> · Equipe <b className="text-violet-300">{blo}</b> · Livres <b>{total - vend - res - blo}</b></p>
            {podeEditar && <Link href={`/admin/campanhas/${id}`} className="mt-3 block rounded-xl bg-gradient-to-r from-[#7C5CFF] to-[#4F46E5] p-3 text-center font-bold text-white">Editar rifa, prêmio e foto</Link>}
          </section>
          <section className={`${card} text-sm text-[#C3D1FF]`}>
            <h3 className="font-bold text-white">O que cada botão faz</h3>
            <ul className="mt-2 grid gap-2">
              <li><b className="text-amber-300">Reservar número:</b> bloqueia números livres (ex.: venda combinada fora do site). Aparecem como reservados para o público.</li>
              <li><b className="text-red-300">Liberar número:</b> solta só os bloqueados pela equipe. Pedidos de clientes são cancelados em <Link href="/admin/compras" className="underline">Compras</Link>.</li>
              <li><b className="text-green-300">Marcar como pago:</b> registra venda manual, com receita no financeiro e auditoria. Exige permissão e justificativa.</li>
            </ul>
          </section>
        </aside>
      </div>
    </main>
  );
}
