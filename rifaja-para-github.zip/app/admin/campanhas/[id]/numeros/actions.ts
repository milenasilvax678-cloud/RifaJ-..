"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../../../lib/supabase/server";

const ACOES = ["bloquear", "liberar", "vender_manual"];
export async function editarNumeros(fd: FormData) {
  const id = String(fd.get("campaign_id"));
  const volta = (ok: boolean, m: string): never => redirect(`/admin/campanhas/${id}/numeros?${ok ? "ok" : "erro"}=${encodeURIComponent(m)}`);
  const acao = String(fd.get("acao"));
  let nums: unknown;
  try { nums = JSON.parse(String(fd.get("numbers") ?? "[]")); } catch { nums = null; }
  if (!ACOES.includes(acao)) volta(false, "Ação inválida.");
  if (!Array.isArray(nums) || !nums.length || nums.length > 100 || !nums.every((n) => Number.isInteger(n))) volta(false, "Escolha de 1 a 100 números na tabela.");
  const motivo = String(fd.get("reason") ?? "").trim() || null;
  const supabase = await createClient();
  let ok = 0, erro = "";
  // Cada número passa pela função do banco, que confere permissão, estado atual e grava a auditoria.
  for (const n of nums as number[]) {
    const { error } = await supabase.rpc("admin_number_action", { p_campaign: id, p_number: n, p_action: acao, p_reason: motivo });
    if (error) { erro = error.message; break; }
    ok++;
  }
  revalidatePath(`/admin/campanhas/${id}/numeros`); revalidatePath("/", "layout");
  volta(!erro, erro ? `${ok} número(s) atualizado(s). Parou no erro: ${erro}` : `${ok} número(s) atualizado(s).`);
}
