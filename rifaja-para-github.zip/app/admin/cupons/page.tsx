import { redirect } from "next/navigation";
import { createClient } from "../../../lib/supabase/server";
import AdminNav from "../nav";
import { criarCupom, alternarCupom, prorrogarCupom } from "./actions";
export const dynamic = "force-dynamic";
const inp = "w-full rounded-xl border border-slate-300 bg-white p-3";
const brl = (c: number) => `R$ ${(c / 100).toFixed(2).replace(".", ",")}`;
const DUR = [["1h", "1 hora"], ["6h", "6 horas"], ["24h", "24 horas"], ["7d", "7 dias"], ["30d", "30 dias"]];

function restante(ms: number) {
  const m = Math.floor(ms / 60000), d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60), mi = m % 60;
  return d ? `${d}d ${h}h` : h ? `${h}h ${mi}min` : `${mi}min`;
}

export default async function Cupons({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("has_permission", { perm: "coupons.read" })).data) redirect("/admin");
  const escreve = !!(await supabase.rpc("has_permission", { perm: "coupons.write" })).data;
  const { data: lista } = await supabase.from("coupons").select("*").order("created_at", { ascending: false });
  const { data: usos } = await supabase.from("coupon_redemptions").select("coupon_id");
  const usosPor = (id: string) => (usos ?? []).filter((u: any) => u.coupon_id === id).length;
  const agora = Date.now();

  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <AdminNav />
      <h1 className="text-3xl font-extrabold">Cupons</h1>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}

      {escreve && (
        <form action={criarCupom} className="mt-6 grid gap-3 rounded-2xl border bg-white p-4">
          <h2 className="text-xl font-bold">Ativar cupom</h2>
          <p className="text-sm text-slate-600">Digite o nome, o desconto e por quanto tempo vale. Ao salvar, o cupom já fica ativo.</p>
          <input name="code" required placeholder="Nome do cupom (ex.: BEMVINDO10)" className={inp} style={{ textTransform: "uppercase" }} autoCapitalize="characters" />
          <div className="grid gap-3 sm:grid-cols-2">
            <select name="discount_type" className={inp}><option value="percentual">Desconto em %</option><option value="valor_fixo">Desconto em R$</option></select>
            <input name="discount_value" required inputMode="decimal" placeholder="Valor do desconto" className={inp} />
            <label className="text-sm">Tempo de duração
              <select name="duration" defaultValue="24h" className={inp}>{DUR.map(([v, t]) => <option key={v} value={v}>{t}</option>)}<option value="none">Sem prazo para acabar</option><option value="custom">Escolher data e hora</option></select></label>
            <label className="text-sm">Se escolheu data e hora (horário de Brasília)<input type="datetime-local" name="expires_at" className={inp} /></label>
            <input name="min_order" inputMode="decimal" placeholder="Compra mínima em R$ (opcional)" className={inp} />
            <input name="max_uses" inputMode="numeric" placeholder="Limite total de usos (opcional)" className={inp} />
            <input name="max_uses_per_user" inputMode="numeric" placeholder="Limite por pessoa (padrão 1)" className={inp} />
          </div>
          <label className="flex gap-2 text-sm"><input type="checkbox" name="new_customers_only" /> Só para novos clientes</label>
          <label className="flex gap-2 text-sm"><input type="checkbox" name="first_purchase_only" /> Só na primeira compra</label>
          <button className="rounded-xl bg-[#1E5BFF] p-3 font-bold text-white">Ativar cupom</button>
        </form>
      )}

      <div className="mt-8 grid gap-3">
        {lista?.map((c: any) => {
          const fim = c.expires_at ? new Date(c.expires_at).getTime() : null;
          const expirado = fim != null && fim <= agora;
          const valendo = c.active && !expirado && (!c.starts_at || new Date(c.starts_at).getTime() <= agora);
          const estado = !c.active ? "Desativado" : expirado ? "Expirado" : "Valendo agora";
          return (
            <div key={c.id} className="rounded-2xl border bg-white p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="font-bold">{c.code} <span className={`ml-2 rounded-full px-2 py-0.5 text-xs ${valendo ? "bg-green-100 text-green-800" : "bg-slate-200 text-slate-700"}`}>{estado}</span></div>
                {escreve && (
                  <form action={alternarCupom}><input type="hidden" name="id" value={c.id} /><input type="hidden" name="ativar" value={c.active ? "0" : "1"} />
                    <button className="rounded-lg border px-3 py-2 text-sm font-bold">{c.active ? "Desativar" : "Ativar"}</button></form>)}
              </div>
              <p className="mt-1 text-sm text-slate-600">
                {c.discount_type === "percentual" ? `${c.discount_value}%` : brl(c.discount_value)} · usos: {usosPor(c.id)}{c.max_uses ? `/${c.max_uses}` : ""}
                {c.min_order_cents ? ` · mínimo ${brl(c.min_order_cents)}` : ""}
              </p>
              <p className="text-sm font-bold">
                {fim == null ? "Sem prazo para acabar" : expirado ? `Expirou em ${new Date(fim).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}` : `Acaba em ${restante(fim - agora)} (${new Date(fim).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })})`}
              </p>
              {escreve && (
                <form action={prorrogarCupom} className="mt-2 flex flex-wrap items-center gap-2">
                  <input type="hidden" name="id" value={c.id} />
                  <select name="duration" className="rounded-lg border p-2 text-sm" aria-label="Somar tempo">{DUR.map(([v, t]) => <option key={v} value={v}>+ {t}</option>)}</select>
                  <button className="rounded-lg bg-[#0A1B4D] px-3 py-2 text-sm font-bold text-white">Prorrogar</button>
                </form>)}
            </div>);
        })}
        {!lista?.length && <p className="rounded-2xl border-2 border-dashed p-5 text-slate-600">Nenhum cupom cadastrado.</p>}
      </div>
    </main>
  );
}
